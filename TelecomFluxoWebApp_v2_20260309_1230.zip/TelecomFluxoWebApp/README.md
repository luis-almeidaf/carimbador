# Fluxos Telecom – Protótipo Web (Python/Flask) v2

Este protótipo implementa o **Modelo A (abas/fluxos separados)** com **variáveis de atendimento** e **carimbo automático**.

## Como executar localmente

1. (Opcional) Ambiente virtual:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate  # Windows
   source .venv/bin/activate   # Linux/macOS
   ```
2. Dependências:
   ```bash
   pip install flask
   ```
3. Rodar:
   ```bash
   cd TelecomFluxoWebApp
   python app.py
   ```
4. Navegar em: http://localhost:5000

## Personalização
- Fluxos: `data/flows.json` (nós `info`, `yesno`, `input`, `select`, `note`)
- Carimbos: `static/js/app.js` (constante `CARIMBOS`)
- Dados do cliente: `data/sample_customer.json`

## Observações
- As variáveis preenchidas ao longo do fluxo ficam visíveis no painel lateral e são inseridas no **carimbo** via `<VAR:chave>`.
- Em produção você pode integrar com sua API, armazenar `trail`/`vars` e adicionar login.

© 2026
