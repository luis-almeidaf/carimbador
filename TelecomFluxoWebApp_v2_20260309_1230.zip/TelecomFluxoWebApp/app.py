from flask import Flask, render_template, jsonify
import json, os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/flows')
def api_flows():
    with open(os.path.join('data','flows.json'), 'r', encoding='utf-8') as f:
        flows = json.load(f)
    return jsonify(flows)

@app.route('/api/customer')
def api_customer():
    with open(os.path.join('data','sample_customer.json'), 'r', encoding='utf-8') as f:
        cust = json.load(f)
    return jsonify(cust)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
