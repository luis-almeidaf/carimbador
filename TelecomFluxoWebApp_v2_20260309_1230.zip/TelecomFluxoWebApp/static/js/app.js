// Protótipo em JS para executar os fluxos no navegador (v2 com variáveis)
const state = {
  customer: null,
  flows: {},
  currentFlowKey: null,
  currentNodeId: null,
  trail: [],
  vars: {}, // variáveis dinâmicas do atendimento
};

const CARIMBOS = {
  NORMALIZADO: `📌 ENCERRAMENTO – NORMALIZADO COM CLIENTE\nCliente: <NOME>\nServiço: <TIPO>\nBD: <NUMERO>\n\nStatus Final: NORMALIZADO\nTestes Realizados: <VAR:testes_realizados>\nAção Técnica: <VAR:acao_tecnica>\nValidação: Cliente confirmou pleno funcionamento\n\nResponsável: <ANALISTA>\nData: <DATA>`,
  DIAGNOSTICO: `📌 ENCERRAMENTO – ENVIADO AO DIAGNÓSTICO\nCliente: <NOME>\nServiço: <TIPO>\nBD: <NUMERO>\n\nFalha Identificada: <VAR:falha_identificada>\nTestes Executados: <VAR:testes_realizados>\nConclusão Técnica: <VAR:conclusao_tecnica>\n\nEncaminhamento: Diagnóstico N2\nResponsável: <ANALISTA>\nData: <DATA>`,
  CAMPO: `📌 ENCERRAMENTO – ENVIADO PARA CAMPO (FIELD)\nCliente: <NOME>\nServiço: <TIPO>\nBD: <NUMERO>\n\nMotivo: <VAR:motivo_campo>\nTestes Realizados: <VAR:testes_realizados>\nConclusão Técnica: <VAR:conclusao_tecnica>\n\nEncaminhamento: GTD / Parceiro\nResponsável: <ANALISTA>\nData: <DATA>`,
  PRE_MASSIVA: `📌 ENCERRAMENTO – PRÉ-MASSIVA\nCliente: <NOME>\nServiço: <TIPO>\nBD: <NUMERO>\n\nIndicador: Possível falha coletiva\nEvidências: <VAR:evidencias_massiva>\n\nEncaminhamento: Pré-Massiva\nResponsável: <ANALISTA>\nData: <DATA>`,
};

async function loadData(){
  const cust = await fetch('/api/customer').then(r=>r.json());
  const flows = await fetch('/api/flows').then(r=>r.json());
  state.customer = cust; state.flows = flows;
  renderCustomer();
  renderFlowSelect();
  renderVars();
}

function renderCustomer(){
  const c = state.customer; if(!c) return;
  const el = document.getElementById('cliente');
  el.innerHTML = `
    <div class="kv"><div><b>Cliente</b></div><div>${c.cliente}</div></div>
    <div class="kv"><div><b>CNPJ</b></div><div>${c.cnpj}</div></div>
    <div class="kv"><div><b>Serviço</b></div><div>${c.servico.tipo} | Circuito ${c.servico.circuito}</div></div>
    <div class="kv"><div><b>Contato</b></div><div>${c.contato.nome} • ${c.contato.telefone} • ${c.contato.email}</div></div>
    <div class="kv"><div><b>BD</b></div><div>${c.chamado.bd} — ${c.chamado.motivo}</div></div>
    <div class="kv"><div><b>Endereço</b></div><div>${c.endereco.instalacao}</div></div>
    <div class="kv"><div><b>Histórico</b></div><div>Última intervenção: ${c.historico.ultima_intervencao} — ${c.historico.observacoes}</div></div>
  `;
}

function renderFlowSelect(){
  const sel = document.getElementById('fluxoSelect');
  sel.innerHTML = '';
  Object.keys(state.flows).forEach(key=>{
    const opt = document.createElement('option');
    opt.value = key; opt.textContent = state.flows[key].title;
    sel.appendChild(opt);
  });
}

function startFlow(){
  const key = document.getElementById('fluxoSelect').value;
  state.currentFlowKey = key;
  const flow = state.flows[key];
  if(!flow) return;
  // zera variáveis e histórico
  state.trail = [];
  state.vars = Object.assign({}, flow.defaults || {});
  state.currentNodeId = flow.start || flow.steps[0].id;
  document.getElementById('carimbo').textContent = '';
  document.getElementById('btnCopy').disabled = true;
  renderVars();
  renderNode();
}

function renderNode(){
  const container = document.getElementById('flowContainer');
  container.innerHTML = '';
  const flow = state.flows[state.currentFlowKey];
  const node = flow.steps.find(s=>s.id===state.currentNodeId);
  if(!node) return;
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `<h3>${node.text} <span class="badge">${node.type}</span></h3>`;

  const controls = document.createElement('div');
  controls.className = 'controls';

  if(node.type === 'info'){
    const btn = document.createElement('button');
    btn.textContent = 'Continuar'; btn.className='btn';
    btn.onclick = ()=>advance('continue');
    controls.appendChild(btn);
  }
  if(node.type === 'yesno'){
    const btnY = document.createElement('button');
    btnY.textContent = 'SIM'; btnY.className='btn';
    btnY.onclick=()=>advance('yes', null, node.yesSet||{});
    const btnN = document.createElement('button');
    btnN.textContent = 'NÃO'; btnN.style.background = 'var(--danger)'; btnN.className='btn';
    btnN.onclick=()=>advance('no', null, node.noSet||{});
    controls.append(btnY, btnN);
  }
  if(node.type === 'input'){
    const lbl = document.createElement('label'); lbl.textContent = node.label||'Valor';
    const inp = document.createElement('input'); inp.placeholder = node.placeholder||''; inp.value = state.vars[node.key]||'';
    const btn = document.createElement('button'); btn.textContent='Salvar'; btn.className='btn';
    btn.onclick=()=>advance('input', {key:node.key, value:inp.value}, node.set||{});
    card.append(lbl, inp);
    controls.appendChild(btn);
  }
  if(node.type === 'select'){
    const lbl = document.createElement('label'); lbl.textContent = node.label||'Selecione';
    const sel = document.createElement('select');
    (node.options||[]).forEach(o=>{ const opt=document.createElement('option'); opt.value=o.value; opt.textContent=o.label; sel.appendChild(opt); });
    const btn = document.createElement('button'); btn.textContent='Selecionar'; btn.className='btn';
    btn.onclick=()=>advance('select', {key:node.key, value:sel.value}, node.set||{});
    card.append(lbl, sel);
    controls.appendChild(btn);
  }
  if(node.type === 'note'){
    const lbl = document.createElement('label'); lbl.textContent = node.label || 'Evidências/Anotações';
    const ta = document.createElement('textarea'); ta.rows = 3; ta.style.width='100%'; ta.placeholder = node.placeholder||''; ta.value = state.vars[node.key]||'';
    const btn = document.createElement('button'); btn.textContent='Salvar'; btn.className='btn';
    btn.onclick=()=>advance('note', {key:node.key, value:ta.value}, node.set||{});
    card.append(lbl, ta);
    controls.appendChild(btn);
  }

  card.appendChild(controls);
  container.appendChild(card);
}

function advance(action, payload=null, setVars={}){
  const flow = state.flows[state.currentFlowKey];
  const node = flow.steps.find(s=>s.id===state.currentNodeId);
  state.trail.push({id: node.id, text: node.text, action, payload});

  // grava variáveis de input/select/note
  if(action==='input' || action==='select' || action==='note'){
    if(payload && payload.key){ state.vars[payload.key] = payload.value; }
  }
  // aplica variáveis definidas por caminho (yes/no) ou set explicito
  if(setVars){ Object.entries(setVars).forEach(([k,v])=>{ state.vars[k]=v; }); }

  // define próximo nó
  let nextId = null;
  if(node.type==='info') nextId = node.next;
  if(node.type==='input' || node.type==='select' || node.type==='note') nextId = node.next;
  if(node.type==='yesno') nextId = (action==='yes') ? node.yes : node.no;

  renderVars();

  if(nextId && nextId.startsWith('END:')){
    const endType = nextId.split(':')[1];
    generateCarimbo(endType);
    return;
  }

  state.currentNodeId = nextId;
  renderNode();
}

function renderVars(){
  const box = document.getElementById('vars');
  const entries = Object.entries(state.vars||{});
  if(entries.length===0){ box.innerHTML = '<p class="muted">Nenhuma variável definida ainda.</p>'; return; }
  let html = '<table><thead><tr><th>Chave</th><th>Valor</th></tr></thead><tbody>';
  entries.forEach(([k,v])=>{ html += `<tr><td>${k}</td><td>${String(v)}</td></tr>`; });
  html += '</tbody></table>';
  box.innerHTML = html;
}

function expandTemplate(tpl){
  const c = state.customer; const vars = state.vars||{}; const now = new Date();
  const base = tpl
    .replaceAll('<NOME>', c?.cliente||'')
    .replaceAll('<TIPO>', c?.servico?.tipo||'')
    .replaceAll('<NUMERO>', c?.chamado?.bd||'')
    .replaceAll('<ANALISTA>', 'Lucas W. W. Benedito')
    .replaceAll('<DATA>', now.toLocaleString('pt-BR'));
  // substitui <VAR:chave>
  return base.replace(/<VAR:([a-zA-Z0-9_]+)>/g, (_, key)=> (vars[key]??''));
}

function generateCarimbo(tipo){
  // prepara campos padrão se não existirem
  if(!state.vars.testes_realizados){
    const parts = [];
    if(state.vars.interface_status) parts.push(`Interface ${state.vars.interface_status}`);
    if(state.vars.ping_loss) parts.push(`Ping perda ${state.vars.ping_loss}%`);
    if(state.vars.sinal_dbm) parts.push(`Sinal ${state.vars.sinal_dbm} dBm`);
    if(state.vars.porta_status) parts.push(`Porta CPE ${state.vars.porta_status}`);
    state.vars.testes_realizados = parts.join(' | ') || 'Ping, ARP, Interface';
  }
  if(!state.vars.acao_tecnica){ state.vars.acao_tecnica = 'Orientação ao cliente (reset/cabos) + validações'; }
  if(!state.vars.conclusao_tecnica){ state.vars.conclusao_tecnica = 'Encaminhamento conforme análise do fluxo'; }
  if(!state.vars.motivo_campo){ state.vars.motivo_campo = 'Necessita verificação presencial (sinal/porta/cabeamento)'; }

  const tpl = CARIMBOS[tipo] || '';
  const text = expandTemplate(tpl);
  const carimboEl = document.getElementById('carimbo');
  carimboEl.textContent = text;
  document.getElementById('btnCopy').disabled = false;
}

function copyCarimbo(){
  const text = document.getElementById('carimbo').textContent;
  navigator.clipboard.writeText(text).then(()=> alert('Carimbo copiado!'));
}

document.getElementById('btnReload').onclick = loadData;
document.getElementById('btnStart').onclick = startFlow;
document.getElementById('btnCopy').onclick = copyCarimbo;

// Inicializa
loadData();
